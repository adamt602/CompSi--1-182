

package project6;

import java.util.Arrays;


public class Student {

    /** Name: Adam Potter
 *  Date: 11/14/18
 *  Description: 
 * 
 */
   
 private String name, sid;
 private double[] homework; 
 private double[] quizzes;
 private double[] exams;
 final static int NUM_HOMEWORK = 4;
 final static int NUM_QUIZZES = 4;
 final static int NUM_EXAMS = 2;
 final static double HOMEWORK_MAX_POINTS = 5.0;
 final static double QUIZ_MAX_POINTS = 20.0;
 final static double MIDTERM_MAX_POINTS = 40.0;
 final static double FINAL_MAX_POINTS = 60.0;
 
 
 public Student(){
     
     name = "Newstudent, A.";
     sid = "“0000000";
     homework = new double[NUM_HOMEWORK];
     quizzes = new double[NUM_QUIZZES];
     exams = new double[NUM_EXAMS];
     
     
 }
 
 public Student(String newName){
     
     name = newName;
     sid = "“0000000";
     homework = new double[NUM_HOMEWORK];
     quizzes = new double[NUM_QUIZZES];
     exams = new double[NUM_EXAMS];
     
 }
 
 public Student(String newName, String newSid){
     name = newName;
     sid = newSid;
     homework = new double[NUM_HOMEWORK];
     quizzes = new double[NUM_QUIZZES];
     exams = new double[NUM_EXAMS];
     
 }
 
 public void setName(String newName){
     
     name = newName;
     
 }
 
 public String getName(){
     
    return name;
 } 
 
 public void setSid(String newSid){
     
     sid = newSid;
     
 }
 
 public String getSid(){
     
     return sid;
     
 }
 
 public void setHomework(int homeworkNumber, double score){
     
     if (homeworkNumber >= 1 && homeworkNumber <= NUM_HOMEWORK 
             && score >= 0 && score <= HOMEWORK_MAX_POINTS){
         
         homework[homeworkNumber - 1] = score;
     
         
     }
    
 }
 
 public double getHomework(int homeworkNumber){
     
     if(homeworkNumber >= 1 && NUM_HOMEWORK >= homeworkNumber){
         
         
         
         return homework[homeworkNumber - 1];
     }
     
     else{
         return 0.0;
     }
     
 }
 
 public void setQuiz(int quizNumber, double score){
     
     if(quizNumber >= 1 && quizNumber <= NUM_QUIZZES && score >= 0 && score <= QUIZ_MAX_POINTS) {
         
         quizzes[quizNumber - 1] = score;
         
         
     }
     
     
 }
 
 public double getQuiz(int quizNumber){
     
     if(quizNumber >= 1 && quizNumber <= NUM_QUIZZES){
     
         return quizzes[quizNumber -1];
     
     }
     
     else{
         return 0.0;
     }
     
 }
 
 public void setMidtermExam(double score){
     
     if(score >= 0 && score <= MIDTERM_MAX_POINTS){
         
         exams[0] = score; 
     }
     
 }
 
 public double getMidtermExam(){
     
     return exams[0];
 }
 
 public void setFinalExam(double score){
     
     if(score >= 0 && score <= FINAL_MAX_POINTS){
         
         exams[1] = score;
     }
     
 }
 
 public double getFinalExam(){
     
     return exams[1];
     
     
 }
 
 
 @Override
 public String toString(){
    
    String data = "Student Name: " + name + " Student sid: " + sid + 
            "\nStudent homework scores: " + Arrays.toString(homework) + 
            "\nStduent quiz scores: " + Arrays.toString(quizzes) + 
            "\nStudent exam scores: " + Arrays.toString(exams);
    
    
    
    
    return data;
    
}
    
    
    
    
    
    
    
    
}
